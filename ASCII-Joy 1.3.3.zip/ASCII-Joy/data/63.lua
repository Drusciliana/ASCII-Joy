--[[
 *	Zone	:: Lebros_Cavern
 *  ZoneID	:: 63
 *  Total	:: 17
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17035374", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[2] = { nm="N", id="17035376", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[3] = { nm="N", id="17035359", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[4] = { nm="N", id="17035360", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[5] = { nm="N", id="17035361", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[6] = { nm="N", id="17035362", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[7] = { nm="N", id="17035363", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[8] = { nm="N", id="17035365", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[9] = { nm="N", id="17035367", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[10] = { nm="N", id="17035369", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[11] = { nm="N", id="17035370", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[12] = { nm="N", id="17035371", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[13] = { nm="N", id="17035372", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[14] = { nm="N", id="17035373", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[15] = { nm="N", id="17035377", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[16] = { nm="N", id="17035368", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }
	mb_data[17] = { nm="N", id="17035378", name="Ranch_Wamouracampa", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="H", links="Y", spawntype="128", weak="Ice", note="" }

	return mb_data;
