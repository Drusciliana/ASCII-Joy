--[[
 *	Zone	:: Provenance
 *  ZoneID	:: 222
 *  Total	:: 15
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17137859", name="Olgoi-Khorkhoi", mj="4", sj="20", mlvl="99-99", behavior="0", aggro="H", links="Y", spawntype="128", weak="???", note="" }
	mb_data[2] = { nm="N", id="17686532", name="CrystalFetter", mj="1", sj="1", mlvl="99-99", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[3] = { nm="N", id="17686530", name="CrystalFetter", mj="1", sj="1", mlvl="99-99", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[4] = { nm="N", id="17686531", name="CrystalFetter", mj="1", sj="1", mlvl="99-99", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[5] = { nm="N", id="17137705", name="Ankabut", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[6] = { nm="N", id="17137976", name="Peaseblossom", mj="1", sj="1", mlvl="99-99", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[7] = { nm="N", id="17686552", name="Wazir", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[8] = { nm="N", id="17686551", name="Shah", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[9] = { nm="N", id="17686546", name="Wazir", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[10] = { nm="N", id="17686541", name="Sarbaz", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[11] = { nm="N", id="17686545", name="Shah", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[12] = { nm="N", id="17686544", name="Rukh", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[13] = { nm="N", id="17686543", name="Asb", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H),T(S)", links="N", spawntype="128", weak="???", note="" }
	mb_data[14] = { nm="N", id="17686542", name="Pil", mj="4", sj="20", mlvl="99-99", behavior="0", aggro="H", links="Y", spawntype="128", weak="???", note="" }
	mb_data[15] = { nm="N", id="17686529", name="Provenancew", mj="4", sj="4", mlvl="99-99", behavior="0", aggro="T(H)", links="N", spawntype="0", weak="???", note="" }

	return mb_data;
