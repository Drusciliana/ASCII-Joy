--[[
 *	Zone	:: Abyssea__Empyreal_Paradox
 *  ZoneID	:: 255
 *  Total	:: 2
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17821698", name="Shinryu", mj="1", sj="4", mlvl="90-92", behavior="0", aggro="T(S)", links="N", spawntype="128", weak="Light", note="" }
	mb_data[2] = { nm="N", id="17821697", name="Shinryu", mj="1", sj="4", mlvl="90-92", behavior="0", aggro="T(S)", links="N", spawntype="128", weak="Light", note="" }

	return mb_data;
