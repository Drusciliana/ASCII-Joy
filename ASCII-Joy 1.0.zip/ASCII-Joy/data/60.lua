--[[
 *	Zone	:: The_Ashu_Talif
 *  ZoneID	:: 60
 *  Total	:: 10
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17022980", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[2] = { nm="N", id="17022989", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[3] = { nm="N", id="17022988", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[4] = { nm="N", id="17022981", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[5] = { nm="N", id="17022982", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[6] = { nm="N", id="17022983", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[7] = { nm="N", id="17022984", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[8] = { nm="N", id="17022985", name="Ashu_Talif_Captain", mj="1", sj="1", mlvl="0-0", behavior="0", aggro="HP,T(H)", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[9] = { nm="N", id="17022986", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }
	mb_data[10] = { nm="N", id="17022987", name="Ashu_Talif_Crew", mj="2", sj="2", mlvl="0-0", behavior="0", aggro="H,HP", links="Y", spawntype="0", weak="Fire,Light", note="" }

	return mb_data;
