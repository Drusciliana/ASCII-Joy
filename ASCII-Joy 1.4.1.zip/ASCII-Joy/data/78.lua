--[[
 *	Zone	:: Hazhalm_Testing_Grounds
 *  ZoneID	:: 78
 *  Total	:: 10
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="17125841", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[2] = { nm="N", id="17125837", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[3] = { nm="N", id="17125842", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[4] = { nm="N", id="17125840", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[5] = { nm="N", id="17125839", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[6] = { nm="N", id="17125843", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[7] = { nm="N", id="17125838", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[8] = { nm="N", id="17126007", name="Momowa", mj="1", sj="1", mlvl="80-85", behavior="8", links="Y", spawntype="128", weak="Piercing,Ice", note="" }
	mb_data[9] = { nm="N", id="17125845", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }
	mb_data[10] = { nm="N", id="17125844", name="MoonfangWarrio", mj="4", sj="4", mlvl="75-80", behavior="144", links="Y", spawntype="128", weak="Fire,Ice,Wind,Earth,Lightning,Water,Light,Dark", note="" }

	return mb_data;
