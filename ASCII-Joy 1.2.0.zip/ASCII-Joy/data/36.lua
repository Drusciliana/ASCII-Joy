--[[
 *	Zone	:: Empyreal_Paradox
 *  ZoneID	:: 36
 *  Total	:: 7
]]--

	mb_data = {}

	mb_data[1] = { nm="N", id="16924675", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[2] = { nm="N", id="16924674", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[3] = { nm="N", id="16924673", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[4] = { nm="N", id="16924676", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[5] = { nm="N", id="16924678", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[6] = { nm="N", id="16924677", name="Promathia", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }
	mb_data[7] = { nm="N", id="17658267", name="Svarbhanu", mj="7", sj="7", mlvl="75-75", behavior="0", aggro="NA", links="N", spawntype="128", weak="???", note="" }

	return mb_data;
